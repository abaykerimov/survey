namespace SurveyTool.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class bd1 : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.Questions", "Answer", c => c.String());
            DropColumn("dbo.Questions", "Question_Answer");
        }
        
        public override void Down()
        {
            AddColumn("dbo.Questions", "Question_Answer", c => c.String());
            DropColumn("dbo.Questions", "Answer");
        }
    }
}
