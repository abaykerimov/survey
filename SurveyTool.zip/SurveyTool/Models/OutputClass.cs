﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SurveyTool.Models
{
    public class OutputClass
    {
        public string Title { get; set; }
        public int ValueOf5 { get; set; }
        public int ValueOf4 { get; set; }
        public int ValueOf3 { get; set; }
        public int ValueOf2 { get; set; }
        public int ValueOf1 { get; set; }
    }
}