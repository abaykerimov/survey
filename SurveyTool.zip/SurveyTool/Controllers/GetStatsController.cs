﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace SurveyTool.Controllers
{
    public class GetStatsController : Controller
    {
        //
        // GET: /GetStats/
        public ActionResult Index()
        {
            SurveyDBEntities1 r = new SurveyDBEntities1();
            var data = r.GetStats().ToList();
            ViewBag.responsedetails = data;
            return View();
        }
	}
}