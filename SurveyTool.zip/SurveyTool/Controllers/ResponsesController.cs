﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using SurveyTool.Models;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.EntityFramework;
using System.Data.SqlClient;

namespace SurveyTool.Controllers
{
    [Authorize]
    public class ResponsesController : Controller
    {
        private readonly ApplicationDbContext _db;

        public ResponsesController(ApplicationDbContext db)
        {
            _db = db;
        }

        [HttpGet]
        public ActionResult Index(int surveyId)
        {
            var responses = _db.Responses
                               .Include("Survey")
                               .Include("Answers")
                               .Include("Answers.Question")
                               .Where(x => x.SurveyId == surveyId)
                               .Where(x => x.CreatedBy == User.Identity.Name)
                               .OrderByDescending(x => x.CreatedOn)
                               .ThenByDescending(x => x.Id)
                               .ToList();

            return View(responses);
        }

        public Boolean isAdminUser()
        {
            if (User.Identity.IsAuthenticated)
            {
                var user = User.Identity;
                ApplicationDbContext context = new ApplicationDbContext();
                var UserManager = new UserManager<ApplicationUser>(new UserStore<ApplicationUser>(context));
                var s = UserManager.GetRoles(user.GetUserId());
                if (s.Contains("Admin"))
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            return false;
        }

        [HttpGet]
        public ActionResult Details(int surveyId, int id)
        {
            ViewBag.Message = "";
            var user_name = _db.Responses.FirstOrDefault(k => k.SurveyId == surveyId).CreatedBy;
            if (user_name != User.Identity.Name)
            {
                ViewBag.Message = "Вы не имеете доступ к чужим ответам";
            }

            var response = _db.Responses
                              .Include("Survey")
                              .Include("Answers")
                              .Include("Answers.Question")
                              .Where(x => x.SurveyId == surveyId)
                              .Where(x => x.CreatedBy == User.Identity.Name)
                              .Single(x => x.Id == id);

            response.Answers = response.Answers.OrderBy(x => x.Question.Priority).ToList();

            var qa = _db.Questions.Where(a => a.SurveyId == surveyId || a.SurveyId == 0).ToList();
            var ans = _db.Answers.Where(b => b.ResponseId == id).ToList();

            int count = 0;

            //var a1 = qa[0].Answer;
            ViewBag.Count = qa.Count();

            foreach (var o in qa)
            {
                foreach (var qn in ans)
                {
                    if (o.Answer == qn.Value) {
                        count++;
                    
                    }
                
                }
            }

            ViewBag.Result = count;

                if (User.Identity.IsAuthenticated)
                {
                    var user = User.Identity;
                    ViewBag.Name = user.Name;

                    ViewBag.displayMenu = "No";

                    if (isAdminUser())
                    {
                        ViewBag.displayMenu = "Yes";
                    }
                    return View(response);
                }
                else
                {
                    ViewBag.Name = "Not Logged IN";
                }  
            return View(response);
        }

        [HttpGet]
        public ActionResult Create(int surveyId)
        {
            var questions = _db.Questions.Where(a => a.SurveyId == surveyId || a.SurveyId == 0).ToList();
            foreach (var i in questions)
            {
                ViewBag.Options = _db.Options.Where(b => b.QuestionId == i.Id).ToList();
            }

            var survey = _db.Surveys
                            .Where(s => s.Id == surveyId)
                            .Select(s => new
                                {
                                    Survey = s,
                                    Questions = s.Questions
                                                 .Where(q => q.IsActive)
                                                 .OrderBy(q => q.Priority)
                                })
                             .AsEnumerable()
                             .Select(x =>
                                 {
                                     x.Survey.Questions = x.Questions.Where(k => k.Priority != 100).ToList();
                                     return x.Survey;
                                 })
                             .Single();
            var randoms = _db.Questions.Where(v => v.Priority == 100).OrderBy(v => Guid.NewGuid()).Take(20).ToList();
            ViewBag.Random = randoms;
            if (User.Identity.IsAuthenticated)
            {
                var user = User.Identity;
                ViewBag.Name = user.Name;

                ViewBag.displayMenu = "No";

                if (isAdminUser())
                {
                    ViewBag.displayMenu = "Yes";
                }
                return View(survey);
            }
            else
            {
                ViewBag.Name = "Not Logged IN";
            }  

            return View(survey);
        }

        [HttpPost]
        public ActionResult Create(int surveyId, string action, Response model)
        {
			if (_db.Responses.Any(user => user.CreatedBy == User.Identity.Name && user.SurveyId == model.SurveyId))
            {
                TempData["warning"] = "Вы уже прошли опрос!";
                return RedirectToAction("Index", "Home");
            }
            else
            {
            model.Answers = model.Answers.Where(a => !String.IsNullOrEmpty(a.Value)).ToList();
            model.SurveyId = surveyId;
            model.CreatedBy = User.Identity.Name;
            model.CreatedOn = DateTime.Now;
            _db.Responses.Add(model);
            _db.SaveChanges();
            var id = _db.Responses.Max(b => b.Id);
            //++response;

            TempData["success"] = "Ваши ответы успешно сохранены!";
                //return Redirect(Request.UrlReferrer.ToString());
            return RedirectToAction("Details", new { surveyId, id });
			}
        }

        public ActionResult AddAnswers(int questions, string answers)
        {
            var id = 1;
            if (_db.Responses.Count() > 0)
            {
                id = _db.Responses.Max(x => x.Id);
                ++id;
            }
                
            string connectionString = @"Data Source=DESKTOP-UNI0FSJ;Initial Catalog=SurveyDB;Integrated Security=True";
            using (SqlConnection connection = new SqlConnection(connectionString))
            using (SqlCommand command = new SqlCommand("", connection))
            {

                command.CommandText = "insert into Answers values(@ResponseId, @QuestionId, @Value, '', '')";
                command.Parameters.AddWithValue("@ResponseId", id);
                command.Parameters.AddWithValue("@QuestionId", questions);
                command.Parameters.AddWithValue("@Value", answers);
                connection.Open();
                command.ExecuteNonQuery();
                connection.Close();
            }

            return Content("added");
            //return RedirectToAction("Details", new { surveyId, id });
        }

        [HttpPost]
        public ActionResult Delete(int surveyId, int id, string returnTo)
        {
            var response = new Response() { Id = id, SurveyId = surveyId };
            _db.Entry(response).State = EntityState.Deleted;
            _db.SaveChanges();
            return Redirect(returnTo ?? Url.RouteUrl("Root"));
        }
    }
}