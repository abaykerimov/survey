﻿using SurveyTool.Repo;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace SurveyTool.Controllers
{
    public class DisplayChartsController : Controller
    {
        // GET: DisplayCharts
        public ActionResult Index()
        {
            return View();
        }

        public JsonResult Barchart()
        {
            MyDataService objMD = new MyDataService();

            var chartsdata = objMD.Listdata(); // calling method Listdata

            return Json(chartsdata, JsonRequestBehavior.AllowGet); // returning list from here.
        }
    }
}