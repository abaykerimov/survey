﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace SurveyTool.Controllers
{
    public class StatisticsController : Controller
    {
        // GET: Statistics
        public ActionResult Index()
        {
            SurveyDBEntity r = new SurveyDBEntity();
            var data = r.TableValue().ToList();
            ViewBag.responsedetails = data;  
            return View();
        }
    }
}