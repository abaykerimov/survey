﻿using SurveyTool.Models;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Dapper;
using System.Data;
using System.Configuration;
using System.Data.SqlClient;
namespace SurveyTool.Repo
{
    public class MyDataService
    {
        public IEnumerable Listdata()
        {
            using (SqlConnection con = new SqlConnection
                  (ConfigurationManager.ConnectionStrings["DefaultConnection"].ToString()))
            {
                string Query = @"select distinct 
  a.QuestionId,
  isnull(t5.val, 0) as '5',
  isnull(t4.val, 0) as '4',
  isnull(t3.val, 0) as '3',
  isnull(t2.val, 0) as '2',
  isnull(t1.val, 0) as '1'
from Answers as a
left outer join (
  select QuestionId, count(*) as val from Answers where Value NOT LIKE '%[^0-9]%' and Value = 5 group by QuestionId
) as t5 on a.QuestionId = t5.QuestionId
left outer join (
  select QuestionId, count(*) as val from Answers where Value NOT LIKE '%[^0-9]%' and Value = 4 group by QuestionId
) as t4 on a.QuestionId = t4.QuestionId
left outer join (
  select QuestionId, count(*) as val from Answers where Value NOT LIKE '%[^0-9]%' and Value = 3 group by QuestionId
) as t3 on a.QuestionId = t3.QuestionId
left outer join (
  select QuestionId, count(*) as val from Answers where Value NOT LIKE '%[^0-9]%' and Value = 2 group by QuestionId
) as t2 on a.QuestionId = t2.QuestionId
left outer join (
  select QuestionId, count(*) as val from Answers where Value NOT LIKE '%[^0-9]%' and Value = 1 group by QuestionId
) as t1 on a.QuestionId = t1.QuestionId;";
                // this is query which in in stored procedure  

                var list = con.Query<OutputClass>("TableValue").AsEnumerable();

                // List of type Outputclass which it will return .  
                return list;
            }
        }
    }
}

/*select distinct 
  a.QuestionId,
  isnull(t5.val, 0) as '5',
  isnull(t4.val, 0) as '4',
  isnull(t3.val, 0) as '3',
  isnull(t2.val, 0) as '2',
  isnull(t1.val, 0) as '1'
from Answers as a
left outer join (
  select QuestionId, count(*) as val from Answers where Value NOT LIKE '%[^0-9]%' and Value = 5 group by QuestionId
) as t5 on a.QuestionId = t5.QuestionId
left outer join (
  select QuestionId, count(*) as val from Answers where Value NOT LIKE '%[^0-9]%' and Value = 4 group by QuestionId
) as t4 on a.QuestionId = t4.QuestionId
left outer join (
  select QuestionId, count(*) as val from Answers where Value NOT LIKE '%[^0-9]%' and Value = 3 group by QuestionId
) as t3 on a.QuestionId = t3.QuestionId
left outer join (
  select QuestionId, count(*) as val from Answers where Value NOT LIKE '%[^0-9]%' and Value = 2 group by QuestionId
) as t2 on a.QuestionId = t2.QuestionId
left outer join (
  select QuestionId, count(*) as val from Answers where Value NOT LIKE '%[^0-9]%' and Value = 1 group by QuestionId
) as t1 on a.QuestionId = t1.QuestionId;*/